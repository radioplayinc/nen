# Hostinger domain → Cloudflare Pages

Pick one method. A is cleaner. B is faster if you do not want to move nameservers.

Replace:
- YOURDOMAIN.com
- SUB = pitch (or www, or @)
- PROJECT = whatever Cloudflare assigns, like nen-cd-pitch.pages.dev

## Method A — Cloudflare as DNS (recommended)

1. Cloudflare → Add a site → YOURDOMAIN.com → Free plan.
2. Cloudflare shows two nameservers, e.g.
   - ada.ns.cloudflare.com
   - bob.ns.cloudflare.com
3. Hostinger hPanel → Domains → YOURDOMAIN.com → Nameservers
   → Change nameservers to the two Cloudflare ones.
4. Wait until Cloudflare says the zone is active (minutes to a few hours).
5. Pages project → Custom domains → Add `pitch.YOURDOMAIN.com`.
6. Cloudflare will create the CNAME automatically if the zone is on Cloudflare.

Apex (YOURDOMAIN.com) also works on Pages via a flattened CNAME.

## Method B — Keep Hostinger DNS, CNAME only

In Hostinger DNS zone editor add:

| Type  | Name  | Points to                 | TTL  |
|-------|-------|---------------------------|------|
| CNAME | pitch | nen-cd-pitch.pages.dev    | 3600 |

Then in Cloudflare Pages → Custom domains → add `pitch.YOURDOMAIN.com`.
Cloudflare will ask you to verify the CNAME.

Do not create an A record for the same host. CNAME and A on the same name conflict.

Apex (@) cannot be a CNAME at most Hostinger zones. Use Method A for the root domain, or use `www` / `pitch`.

## SSL

Cloudflare Pages issues HTTPS automatically after the domain verifies.
Force HTTPS in Pages settings.

## What not to do

- Do not point the domain at the old trycloudflare.com tunnel. That dies with the session.
- Do not upload only index.html without the `img/` folder.
- Do not set a build command. This is a static folder.
